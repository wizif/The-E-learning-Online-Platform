import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import CourseCard from '../components/CourseCard';
import Testimonials from '../components/Testimonials';
import CategoriesSection from '../components/Categories';
import FAQSection from '../components/Faq';
import CourseCarousel from '../components/CourseCarousel';
import Footer from '../components/Footer';

import '../styles/Home.css';
import courses from '../data/courses';
import Hero from '../components/Hero';
import Categories from '../components/Categories';

gsap.registerPlugin(ScrollTrigger);

const Home = () => {
  const heroRef = useRef();

  useEffect(() => {
    // Hero section animation
    if (heroRef.current) {
      gsap.from(heroRef.current, {
        y: 50,
        opacity: 0,
        duration: 1,
        ease: 'power3.out',
      });
    }

    // Animate other sections on scroll
    gsap.utils.toArray('section').forEach(section => {
      gsap.from(section, {
        opacity: 0,
        y: 50,
        duration: 1,
        scrollTrigger: {
          trigger: section,
          start: 'top 80%',
          toggleActions: 'play none none none'
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const popularCourses = courses.slice(0, 3);

  return (
    <div className="home">
<Hero/>

      {/* Course Carousel */}
      <CourseCarousel />

      {/* Categories Section */}
      <Categories />

      {/* Popular Courses Section */}
      <section className="courses">
        <h2>Our Popular Courses</h2>
        <div className="container courses__container">
          {popularCourses.map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </section>

      {/* FAQs Section */}
      <FAQSection />

      {/* Testimonials Section */}
      <Testimonials />

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Home;