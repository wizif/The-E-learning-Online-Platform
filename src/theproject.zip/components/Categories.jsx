import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  FaBitcoin, 
  FaPalette, 
  FaDollarSign, 
  FaBullhorn, 
  FaMusic, 
  FaPuzzlePiece 
} from 'react-icons/fa';
import '../styles/Categories.css';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

const Categories = ({ selectedCategory, setSelectedCategory }) => {
  const sectionRef = useRef(null);
  const headingRef = useRef(null);
  const subtitleRef = useRef(null);
  const gridRef = useRef(null);
  const cardsRef = useRef([]);

  const categories = [
    { name: 'All', icon: <FaPuzzlePiece />, color: '#6366f1' },
    { name: 'Blockchain', icon: <FaBitcoin />, color: '#f59e0b' },
    { name: 'Design', icon: <FaPalette />, color: '#ec4899' },
    { name: 'Finance', icon: <FaDollarSign />, color: '#10b981' },
    { name: 'Marketing', icon: <FaBullhorn />, color: '#3b82f6' },
    { name: 'Music', icon: <FaMusic />, color: '#8b5cf6' },
  ];

  // Add card to ref array
  const addToCardsRef = (el) => {
    if (el && !cardsRef.current.includes(el)) {
      cardsRef.current.push(el);
    }
  };

  useEffect(() => {
    // Section animation
    gsap.from(sectionRef.current, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      opacity: 0,
      y: 50,
      duration: 0.8,
      ease: 'power3.out'
    });

    // Heading animation
    gsap.from(headingRef.current, {
      scrollTrigger: {
        trigger: headingRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      opacity: 0,
      y: 30,
      duration: 0.6,
      delay: 0.2,
      ease: 'power3.out'
    });

    // Subtitle animation
    gsap.from(subtitleRef.current, {
      scrollTrigger: {
        trigger: subtitleRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      opacity: 0,
      y: 20,
      duration: 0.6,
      delay: 0.4,
      ease: 'power3.out'
    });

    // Cards stagger animation
    gsap.from(cardsRef.current, {
      scrollTrigger: {
        trigger: gridRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
      opacity: 0,
      y: 50,
      duration: 0.8,
      stagger: 0.1,
      ease: 'back.out(1.7)',
      delay: 0.6
    });

    // Hover animations for each card
    cardsRef.current.forEach((card, index) => {
      const icon = card.querySelector('.category-icon');
      const color = categories[index].color;

      // Set initial color
      gsap.set(card, { '--category-color': color });

      // Hover animation
      card.addEventListener('mouseenter', () => {
        gsap.to(icon, {
          y: -5,
          scale: 1.1,
          duration: 0.3,
          ease: 'power2.out'
        });
      });

      card.addEventListener('mouseleave', () => {
        gsap.to(icon, {
          y: 0,
          scale: 1,
          duration: 0.3,
          ease: 'power2.out'
        });
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section className="categories" ref={sectionRef}>
      <div className="container">
        <h2 ref={headingRef}>Browse Categories</h2>
        <p className="categories__subtitle" ref={subtitleRef}>
          Explore our wide range of course categories
        </p>
        <div className="categories__grid" ref={gridRef}>
          {categories.map((category, index) => (
            <div
              key={category.name}
              ref={addToCardsRef}
              className={`category-card ${selectedCategory === category.name ? 'active' : ''}`}
              onClick={() => setSelectedCategory(category.name)}
              style={{ '--category-color': category.color }}
            >
              <div className="category-icon">
                {category.icon}
              </div>
              <h3>{category.name}</h3>
              <span className="category-count">{Math.floor(Math.random() * 20) + 5} courses</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;